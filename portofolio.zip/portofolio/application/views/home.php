<!DOCTYPE html>
<html lang="zxx">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Portfolio Prisilia</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?=base_url('asset/images/logotitle2.png');?>" />

    <!-- CSS
    ============================================ -->

    <!-- Vendor CSS (Contain Bootstrap, Icon Fonts) -->
    <link rel="stylesheet" href="<?=base_url('asset/css/vendor/bootstrap.min.css');?>" />
    <link rel="stylesheet" href="<?=base_url('asset/css/vendor/icofont.min.css');?>" />

    <!-- Plugin CSS (Global Plugins Files) -->
    <link rel="stylesheet" href="<?=base_url('asset/css/plugins/animate.css');?>">
    <link rel="stylesheet" href="<?=base_url('asset/css/plugins/swiper-bundle.min.css');?>">
    <link rel="stylesheet" href="<?=base_url('asset/css/plugins/nice-select.css');?>">
    <link rel="stylesheet" href="<?=base_url('asset/css/plugins/venobox.min.css');?>" />


    <!-- Font Awesome 5 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />

    
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?=base_url('asset/css/style.css');?>">
    

</head>

<body>

    <main class="main-wrapper">
    <div id="particles-js"></div>
        <!-- .....:::::: Start Header Section :::::.... -->
        <header class="header-section sticky-header d-none d-lg-block">
        
            <div class="header-wrapper">
                <div class="container">
                    <div class="row justify-content-between align-items-center">
                        <div class="col">
                            <!-- Start Header Logo -->
                            <a href="index.html" class="header-logo">
                                <img src="<?=base_url('asset/images/logoheader2.png');?>" alt="">
                            </a>
                            <!-- End Header Logo -->
                        </div>
                        <div class="col-auto">
                            <!-- Start Header Menu -->
                            <ul class="header-nav">
                                <li><a href="index.html">Home</a></li>
                                <li class="has-dropdown">
                                    <a href="service-list.html">Service</a>
                                    <ul class="submenu">
                                        <li><a href="service-list.html">Services</a></li>
                                        <li><a href="service-details.html">Service Details</a></li>
                                    </ul>
                                </li>
                                <li class="has-dropdown">
                                    <a href="blog-list.html">Blog</a>
                                    <ul class="submenu">
                                        <li><a href="blog-list.html">Blog List Full Width</a></li>
                                        <li><a href="blog-list-sidebar-left.html">Blog List Left Sidebar</a></li>
                                        <li><a href="blog-list-sidebar-right.html">Blog List Right Sidebar</a></li>
                                        <li><a href="blog-details.html">Blog Details Full Width</a></li>
                                        <li><a href="blog-details-sidebar-left.html">Blog Details Left Sidebar</a></li>
                                        <li><a href="blog-details-sidebar-right.html">Blog Details Right Sidebar</a></li>
                                    </ul>
                                </li>
                                <li class="has-dropdown">
                                    <a href="#">Pages</a>
                                    <ul class="submenu">
                                        <li><a href="about.html">About Us</a></li>
                                    <li><a href="project-list.html">Project</a></li>
                                    <li><a href="project-details.html">Project Details</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="404-page.html">404 Page</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                            <!-- End Header Menu -->
                        </div>
                        <div class="col">
                            <div class="header-btn-link text-end">
                               <a href="contact.html" class="btn btn-sm btn-outline-one icon-space-left">Hire Me <i class="fas fa-hands-helping"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- .....:::::: End Header Section :::::.... -->

        <!-- .....:::::: Start Mobile Header Section :::::.... -->
        <div class="mobile-header d-block d-lg-none">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col">
                        <div class="mobile-logo">
                            <a href="index.html"><img src="<?=base_url('assets/images/logo/logo.png');?>" alt=""></a>
                        </div>
                    </div>
                    <div class="col">
                        <div class="mobile-action-link text-end">
                            <a href="#mobile-menu-offcanvas" class="offcanvas-toggle offside-menu"><i class="icofont-navigation-menu"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .....:::::: Start MobileHeader Section :::::.... -->

        <!--  Start Offcanvas Mobile Menu Section -->
        <div id="mobile-menu-offcanvas" class="offcanvas offcanvas-rightside offcanvas-mobile-menu-section">
            <!-- Start Offcanvas Header -->
            <div class="offcanvas-header text-end">
                <button class="offcanvas-close"><i class="icofont-close-line"></i></button>
            </div> <!-- End Offcanvas Header -->
            <!-- Start Offcanvas Mobile Menu Wrapper -->
            <div class="offcanvas-mobile-menu-wrapper">
                <!-- Start Mobile Menu  -->
                <div class="mobile-menu-bottom">
                    <!-- Start Mobile Menu Nav -->
                    <div class="offcanvas-menu">
                        <ul>
                            <li>
                                <a href="index.html"><span>Home</span></a>
                            </li>
                            <li>
                                <a href="#"><span>Services</span></a>
                                <ul class="mobile-sub-menu">
                                    <li><a href="service-list.html">Service List</a></li>
                                    <li><a href="service-details.html">Service Details</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#"><span>Blog</span></a>
                                <ul class="mobile-sub-menu">
                                    <li><a href="blog-list.html">Blog List Full Width</a></li>
                                    <li><a href="blog-list-sidebar-left.html">Blog List Left Sidebar</a></li>
                                    <li><a href="blog-list-sidebar-right.html">Blog List Right Sidebar</a></li>
                                    <li><a href="blog-details.html">Blog Details Full Width</a></li>
                                    <li><a href="blog-details-sidebar-left.html">Blog Details Left Sidebar</a></li>
                                    <li><a href="blog-details-sidebar-right.html">Blog Details Right Sidebar</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#"><span>Pages</span></a>
                                <ul class="mobile-sub-menu">
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="project-list.html">Project</a></li>
                                    <li><a href="project-details.html">Project Details</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="404-page.html">404 Page</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="contact.html"><span>Contact</span></a>
                            </li>
                        </ul>
                    </div> <!-- End Mobile Menu Nav -->
                </div> <!-- End Mobile Menu -->

                <!-- Start Mobile contact Info -->
                <div class="mobile-contact-info text-center">
                    <ul class="social-link">
                        <li><a target="_blank" href="https://example.com"><i class="icofont-facebook"></i></a>
                        </li>
                        <li><a target="_blank" href="https://example.com"><i class="icofont-twitter"></i></a>
                        </li>
                        <li><a target="_blank" href="https://example.com"><i class="icofont-skype"></i></a></li>
                    </ul>
                </div>
                <!-- End Mobile contact Info -->

            </div> <!-- End Offcanvas Mobile Menu Wrapper -->
        </div>
        <!-- ...:::: End Offcanvas Mobile Menu Section:::... -->

        <!-- Offcanvas Overlay -->
        <div class="offcanvas-overlay"></div>

        <!-- ...::: Start Hero Section :::... -->
        <div class="hero-section section-dark-blue-bg">
            <div class="hero-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-xxl-7">
                            <div class="hero-content">
                                <h3 class="title-big">Hello! I’m</h3>
                                <h2 class="title-large">Chatleen <span class="shape-mark">Prycilia</span></h2>
                                <p>3D Animator & Web Developer</p>

                                <a href="#" class="btn btn-xl btn-outline-one icon-space-left">Get Resume <i class="far fa-file"></i></a>

                                <div class="video-link">
                                    <a class="wave-btn" href="https://youtu.be/MKjhBO2xQzg" data-autoplay="true" data-vbtype="video">

                                        <div class="ripple"><i class="fab fa-youtube"></i></div>
                                    </a>

                                    <span class="video-text"> Watch Video</span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="hero-shape hero-top-shape">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="hero-shape hero-bottom-shape">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

                <div class="hero-portrait">
                    <div class="image">
                        <img class="img-fluid" src="assets/images/portrait/portrait-hero.png" alt="">

                        <div class="image-half-round-shape"></div>
                        <div class="social-link">
                            <a href="https://www.example.com" target="_blank"><i class="icofont-facebook"></i></a>
                            <a href="https://www.example.com" target="_blank"><i class="icofont-dribbble"></i></a>
                            <a href="https://www.example.com" target="_blank"><i class="icofont-behance"></i></a>
                            <a href="https://www.example.com" target="_blank"><i class="icofont-linkedin"></i></a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- ...::: End Hero Section :::... -->



        <!-- ...::: Start Resume Info Display Section :::... -->
        <div class="resume-info-display-section  section-gap-tb-165 section-bg">
            <div class="resume-info-display-box">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <ul class="resume-tab nav">
                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#education-tab">Education</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#experience-tab">Experience</button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="resume-info-display-wrapper">
                        <div class="row">
                            <div class="col-12">
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="education-tab" role="tabpanel">
                                        <ul class="resume-list">
                                            <!-- Start Resume Tab List Single Item -->
                                            <li class="resume-tab-list-single-item">
                                                <div class="content">
                                                    <div class="left">
                                                        <span class="year">2010 - 2013</span>
                                                    </div>
                                                    <div class="right">
                                                        <h3 class="title">Junior High School</h3>
                                                        <span class="institute-name">SMPN 1, Manado</span>
                                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been indus dard dummy text ever since the 1500 when an uniknown prnter took galley of type and scrambled make specimen book has not only five centuries the into electronic.</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End Resume Tab List Single Item -->
                                            <!-- Start Resume Tab List Single Item -->
                                            <li class="resume-tab-list-single-item">
                                                <div class="content">
                                                    <div class="left">
                                                        <span class="year">2013 - 2016</span>
                                                    </div>
                                                    <div class="right">
                                                        <h3 class="title">Senior High School </h3>
                                                        <span class="institute-name">Eben Haezar Christian Senior High School, Manado</span>
                                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been indus dard dummy text ever since the 1500 when an uniknown prnter took galley of type and scrambled make specimen book has not only five centuries the into electronic.</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End Resume Tab List Single Item -->
                                            <!-- Start Resume Tab List Single Item -->
                                            <li class="resume-tab-list-single-item">
                                                <div class="content">
                                                    <div class="left">
                                                        <span class="year">2016 - 2020</span>
                                                    </div>
                                                    <div class="right">
                                                        <h3 class="title">Bachelor of Computer Science</h3>
                                                        <span class="institute-name">University of Sam Ratulangi, Manado</span>
                                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been indus dard dummy text ever since the 1500 when an uniknown prnter took galley of type and scrambled make specimen book has not only five centuries the into electronic.</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End Resume Tab List Single Item -->
                                        </ul>
                                    </div>
                                    <div class="tab-pane fade" id="experience-tab" role="tabpanel">
                                        <ul class="resume-list">
                                            <!-- Start Resume Tab List Single Item -->
                                            <li class="resume-tab-list-single-item">
                                                <div class="content">
                                                    <div class="left">
                                                        <span class="year">2021 - Now</span>
                                                    </div>
                                                    <div class="right">
                                                        <h3 class="title">Junior Web Developer</h3>
                                                        <span class="institute-name">KOMINFO Pemerintah Provinsi Sulawesi Utara</span>
                                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been indus dard dummy text ever since the 1500 when an uniknown prnter took galley of type and scrambled make specimen book has not only five centuries the into electronic.</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End Resume Tab List Single Item -->
                                            <!-- Start Resume Tab List Single Item -->
                                            <li class="resume-tab-list-single-item">
                                                <div class="content">
                                                    <div class="left">
                                                        <span class="year"> </span>
                                                    </div>
                                                    <div class="right">
                                                        <h3 class="title"> </h3>
                                                        <span class="institute-name"> </span>
                                                        <p> </p>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End Resume Tab List Single Item -->
                                            <!-- Start Resume Tab List Single Item -->
                                            <li class="resume-tab-list-single-item">
                                                <div class="content">
                                                    <div class="left">
                                                        <span class="year"></span>
                                                    </div>
                                                    <div class="right">
                                                        <h3 class="title"> </h3>
                                                        <span class="institute-name"> </span>
                                                        <p> </p>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End Resume Tab List Single Item -->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ...::: End Resume Info Display Section :::... -->


        <!-- ...::: Start Service Display Section :::... -->
        <div class="service-display-section section-gap-tb-165 pos-relative">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- Start Section Content -->
                        <div class="section-content">
                            <span class="section-tag">My Services</span>
                            <h2 class="section-title">Service Provide For My Clients.</h2>
                        </div>
                        <!-- End Section Content -->
                    </div>
                </div>
            </div>

            <!-- Start Service Section Wrapper -->
            <div class="service-display-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="service-display-slider">
                                <!-- Slider main container -->
                                <div class="swiper-container">
                                    <!-- Additional required wrapper -->
                                    <div class="swiper-wrapper">
                                        <!-- Slides -->
                                        <!-- Start Service Box Single Item -->
                                        <div class="service-box-single-item swiper-slide">
                                            <div class="inner-shape inner-shape-top-right"></div>
                                            <div class="icon"><img src="<?=base_url('asset/assets/images/icon/service-icon-1.png');?>" alt=""></div>
                                            <h4 class="title"><a href="service-details.html">UI/UX Design</a></h4>
                                            <ul>
                                                <li><i class="fas fa-check"></i> Landing Pages</li>
                                                <li></li>
                                                <li>Wireframing</li>
                                                <li>Prototyping</li>
                                                <li>Mobile App Design</li>
                                            </ul>
                                            <div class="inner-shape inner-shape-bottom-right"></div>
                                        </div>
                                        <!-- End Service Box Single Item -->
                                        <!-- Start Service Box Single Item -->
                                        <div class="service-box-single-item swiper-slide">
                                            <div class="inner-shape inner-shape-top-right"></div>
                                            <div class="icon"><img src="assets/images/icon/service-icon-2.png" alt=""></div>
                                            <h4 class="title"><a href="service-details.html">3D Animator</a></h4>
                                            <ul class="list-item">
                                                <li>Modelling Object & Character</li>
                                                <li>Texturing</li>
                                                <li>Rigging</li>
                                            </ul>
                                            <div class="inner-shape inner-shape-bottom-right"></div>
                                        </div>
                                        <!-- End Service Box Single Item -->
                                        <!-- Start Service Box Single Item -->
                                        <div class="service-box-single-item swiper-slide">
                                            <div class="inner-shape inner-shape-top-right"></div>
                                            <div class="icon"><img src="assets/images/icon/service-icon-3.png" alt=""></div>
                                            <h4 class="title"><a href="service-details.html">Web Dev</a></h4>
                                            <ul class="list-item">
                                                <li>CSS</li>
                                                <li>HTML</li>
                                                <li>JAVASCRIPT</li>
                                            </ul>
                                            <div class="inner-shape inner-shape-bottom-right"></div>
                                        </div>
                                        <!-- End Service Box Single Item -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- If we need pagination -->
                <div class="service-display-dots">
                    <div class="swiper-pagination"></div>
                </div>
            </div>
            <!-- End Service Section Wrapper -->
        </div>
        <!-- ...::: End Service Display Section :::... -->

        <!-- ...::: Start Skill Display Section :::... -->
        <div class="skill-display-section section-gap-tb-165 section-bg pos-relative">
            <div class="skill-display-section-box">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-6 col-xxl-5">
                            <!-- Start Section Content -->
                            <div class="section-content">
                                <span class="section-tag">Special Skills</span>
                                <h2 class="section-title">My Special Skill Field Here.</h2>

                                <a href="#" class="btn btn-xl btn-outline-one icon-space-left">Get Resume <i class="far fa-file"></i></a>
                            </div>
                            <!-- End Section Content -->
                        </div>

                        <div class="col-xl-6 col-xxl-6 offset-xxl-1">
                            <!-- Start Skill Display Wrapper -->
                            <div class="skill-display-wrapper">
                                <!-- Start Skill Progress Single Item -->
                                <div class="skill-progress-single-item">
                                    <span class="tag">3D Animation</span>
                                    <div class="skill-box">
                                        <div class="progress-line" data-width="80">
                                            <span class="skill-percentage">85%</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- ENd Skill Progress Single Item -->
                                <!-- Start Skill Progress Single Item -->
                                <div class="skill-progress-single-item">
                                    <span class="tag">HTML</span>
                                    <div class="skill-box">
                                        <div class="progress-line" data-width="70">
                                            <span class="skill-percentage">80%</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- ENd Skill Progress Single Item -->
                                <!-- Start Skill Progress Single Item -->
                                <div class="skill-progress-single-item">
                                    <span class="tag">CSS</span>
                                    <div class="skill-box">
                                        <div class="progress-line" data-width="70">
                                            <span class="skill-percentage">70%</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- ENd Skill Progress Single Item -->
                                <!-- Start Skill Progress Single Item -->
                                <div class="skill-progress-single-item">
                                    <span class="tag">Video Editing</span>
                                    <div class="skill-box">
                                        <div class="progress-line" data-width="55">
                                            <span class="skill-percentage">55%</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- ENd Skill Progress Single Item -->
                                <div class="skill-progress-single-item">
                                    <span class="tag">Design Grafis</span>
                                    <div class="skill-box">
                                        <div class="progress-line" data-width="40">
                                            <span class="skill-percentage">40%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Skill Display Wrapper -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="skill-display-shape"></div>
        </div>
        <!-- ...::: End Skill Display Section :::... -->

       
        <!-- ...::: Start Project Display Section :::... -->
        <div class="project-display-section section-gap-tb-165">
            <div class="project-display-box">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-xl-12 d-block d-md-flex justify-content-between">
                            <!-- Start Section Content -->
                            <div class="section-content pos-relative">
                                <span class="section-tag">Awesome Portfolio</span>
                                <h2 class="section-title">My Complete Projects</h2>
                            </div>
                            <!-- End Section Content -->

                            <div class="default-nav-style mt-6 mb-6 mb-md-0 ">
                                <!-- If we need navigation buttons -->
                                <div class="slider-button button-prev"><i class="fas fa-hand-point-left fa-4x"></i></div>
                                <div class="slider-button button-next"><i class="fas fa-hand-point-right fa-4x"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="project-display-wrapper">
                    <div class="project-display-slider">
                        <!-- Swiper -->
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <!-- Slides -->
                                <!-- Start Project Box Single Item -->
                                <div class="project-box-single-item swiper-slide">
                                    <div class="img-box">
                                        <div class="bg-overlay"></div>
                                        <div class="bg-image">
                                            <img src="<?=base_url('asset/images/project2.png');?>" alt="">
                                        </div>
                                        <div class="image">
                                            <img src="<?=base_url('asset/images/project2.png');?>" alt="">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="project-details.html">Website Dinas Pemuda Dan Olahraga Provinsi Sulawesi Utara</a></h4>

                                        
                                    </div>
                                </div>
                                <!-- End Project Box Single Item -->
                                <!-- Start Project Box Single Item -->
                                <div class="project-box-single-item swiper-slide">
                                    <div class="img-box">
                                        <div class="bg-overlay"></div>
                                        <div class="bg-image">
                                            <img src="<?=base_url('asset/images/project3.png');?>" alt="">
                                        </div>
                                        <div class="image">
                                            <img src="<?=base_url('asset/images/project4.png');?>" alt="">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="project-details.html">Website Dinas Perhubungan Provinsi Sulawesi Utara</a></h4>

                                       
                                    </div>
                                </div>
                                <!-- End Project Box Single Item -->
                                <!-- Start Project Box Single Item -->
                                <div class="project-box-single-item swiper-slide">
                                    <div class="img-box">
                                        <div class="bg-overlay"></div>
                                        <div class="bg-image">
                                            <img src="<?=base_url('asset/images/project3.png');?>" alt="">
                                        </div>
                                        <div class="image">
                                            <img src="<?=base_url('asset/images/project3.png');?>" alt="">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="project-details.html">Website Badan Pengelola Perbatasan</a></h4>

                                        
                                    </div>
                                </div>
                                <!-- End Project Box Single Item -->
                                <!-- Start Project Box Single Item -->
                                <div class="project-box-single-item swiper-slide">
                                    <div class="img-box">
                                        <div class="bg-overlay"></div>
                                        <div class="bg-image">
                                            <img src="<?=base_url('asset/images/project1.png');?>" alt="">
                                        </div>
                                        <div class="image">
                                            <img src="<?=base_url('asset/images/project1.png');?>" alt="">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="project-details.html">Video Animasi Interaktif 3D Dampak Penggunaan Gadget</a></h4>

                                        
                                    </div>
                                </div>
                                <!-- End Project Box Single Item -->
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- ...::: End Project Display Section :::... -->

        <!-- ...::: Start Testimonial Display Section :::... -->
        <div class="testimonial-display-section section-gap-tb-165 section-bg">
            <div class="testimonial-display-box d-flex flex-column align-items-center d-xl-block pos-relative">
                <div class="container overflow-hidden">
                    <div class="row">
                        <div class="col d-xl-flex justify-content-xl-end">
                            <!-- Start Section Content -->
                            <div class="section-content pos-relative">
                                <span class="section-tag">Quotes</span>
                                <h2 class="section-title">Bible Say's</h2>
                            </div>
                            <!-- End Section Content -->
                        </div>
                    </div>

                    <div class="testimonial-display-wrapper">
                        <div class="row">
                            <div class="col-12">
                                <div class="testimonial-display-slider">
                                    <!-- Swiper -->
                                    <div class="swiper-container">
                                        <div class="swiper-wrapper">
                                            <!-- Start testimonial Slider Single Item -->
                                            <div class="testimonial-slider-single-item swiper-slide">
                                                <div class="inner-shape inner-shape-top-right"></div>
                                                <div class="content">
                                                    <span class="icon">“</span>
                                                    <p class="text">There is no fear in love. But perfect love drives out fear, because fear has to do with punishment. The one who fears is not made perfect in love.</p>
                                                    <div class="info">
                                                        <div class="author">
                                                            <h4 class="name">John 4:18 </h4>
                                                            <!-- <span class="designation">CEO, Seoly</span> -->
                                                        </div>
                                                        <ul class="review">
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End testimonial Slider Single Item -->
                                            <!-- Start testimonial Slider Single Item -->
                                            <div class="testimonial-slider-single-item swiper-slide">
                                                <div class="inner-shape inner-shape-top-right"></div>
                                                <div class="content">
                                                    <span class="icon">“</span>
                                                    <p class="text">"For I know the plans I have for you," declares the LORD, "plans to prosper you and not to harm you, plans to give you hope and a future."</p>
                                                    <div class="info">
                                                        <div class="author">
                                                            <h4 class="name">Jeremiah 29:11 </h4>
                                                            <!-- <span class="designation">CEO, Seoly</span> -->
                                                        </div>
                                                        <ul class="review">
                                                        <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End testimonial Slider Single Item -->
                                            <!-- Start testimonial Slider Single Item -->
                                            <div class="testimonial-slider-single-item swiper-slide">
                                                <div class="inner-shape inner-shape-top-right"></div>
                                                <div class="content">
                                                    <span class="icon">“</span>
                                                    <p class="text">And we know that in all things God works for the good of those who love him, who have been called according to his purpose.</p>
                                                    <div class="info">
                                                        <div class="author">
                                                            <h4 class="name">Romans 8:28 </h4>
                                                            <!-- <span class="designation">CEO, Seoly</span> -->
                                                        </div>
                                                        <ul class="review">
                                                        <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                            <li class="fill"><i class="fas fa-star"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End testimonial Slider Single Item -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="default-nav-style mt-5 mt-xl-0">
                    <!-- If we need navigation buttons -->
                    <div class="slider-button button-prev"><i class="fas fa-hand-point-left fa-4x"></i></div>
                    <div class="slider-button button-next"><i class="fas fa-hand-point-right fa-4x"></i></div>
                </div>
            </div>
        </div>
        <!-- ...::: End Testimonial Display Section :::... -->

        

        

        <!-- ...::: Start Footer Section :::... -->
        <footer class="footer-section section-bg overflow-hidden pos-relative">
            <div class="footer-inner-shape-top-left"></div>
            <div class="footer-inner-shape-top-right"></div>
            <div class="footer-section-top section-gap-t-165">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Start Section Content -->
                            <div class="section-content pos-relative text-center">
                                <span class="section-tag">Contact</span>
                                <h2 class="section-title">Contact me at : </h2>
                            </div>
                            <!-- End Section Content -->
                        </div>
                    </div>
                   
                </div>
            </div>
            <div class="footer-center section-gap-tb-165">
                <div class="container">
                    <div class="row justify-content-between align-items-center mb-n5">
                        <div class="col-auto mb-5">
                            <!-- Start Single Footer Info -->
                            <div class="footer-single-info">
                                <a href="tel:+0123456789" class="info-box">
                                    <span class="icon"><i class="fas fa-phone fa-3x"></i></span>
                                    <span class="text">087882114510</span>
                                </a>
                            </div>
                            <!-- Start Single Footer Info -->
                        </div>
                        <div class="col-auto mb-5">
                            <!-- Start Single Footer Info -->
                            <div class="footer-single-info">
                                <a href="mailto:chatleenprisilia@mdteam.id" class="info-box">
                                    <span class="icon"><i class="fas fa-envelope-open-text fa-3x"></i></span>
                                    <span class="text">chatleenprisilia@mdteam.id</span>
                                </a>
                            </div>
                            <!-- Start Single Footer Info -->
                        </div>
                        <div class="col-auto mb-5">
                            <!-- Start Single Footer Info -->
                            <div class="footer-single-info">
                                <ul class="social-link">
                                    <li><a href="https://www.example.com" target="_blank"><i class="fab fa-facebook-f fa-2x"></i></a></li>
                                    <li><a href="https://www.example.com" target="_blank"><i class="fab fa-instagram fa-2x"></i></a></li>
                                    <li><a href="https://www.example.com" target="_blank"><i class="fab fa-whatsapp fa-2x"></i></a></li>
                                </ul>
                            </div>
                            <!-- Start Single Footer Info -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row justify-content-center justify-content-md-between align-items-center flex-column-reverse flex-md-row">
                        <div class="col-auto">
                            <div class="footer-copyright">
                                <p class="copyright-text">&copy; 2021 <a href="index.html"></a> Made with <i class="fas fa-heart"></i> by <a href="https://hasthemes.com/" target="_blank">Chatleen Prycilia Ompi</a> </p>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="index.html" class="footer-logo">
                                <div class="logo">
                                    <img src="<?=base_url('asset/images/logoheader2.png');?>" alt="">
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- ...::: End Footer Section :::... -->

        <!-- material-scrolltop button -->
    <button class="material-scrolltop" type="button"></button>
    </main>

    <!-- Global Vendor, plugins JS -->

    <!-- JS Files
    ============================================ -->
    <!-- Global Vendor, plugins JS -->

    <!-- Vendor JS -->
    <script src="<?=base_url('asset/js/vendor/bootstrap.bundle.min.js');?>"></script>
    <script src="<?=base_url('asset/js/vendor/jquery-3.5.1.min.js');?>"></script>
    <script src="<?=base_url('asset/js/vendor/jquery-migrate-3.3.0.min.js');?>"></script>
    <script src="<?=base_url('asset/js/vendor/modernizr-3.11.2.min.js');?>"></script>

    <!--Plugins JS-->
    <script src="<?=base_url('asset/js/plugins/swiper-bundle.min.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/jquery.appear.min.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/jquery.nice-select.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/venobox.min.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/jquery.waypoints.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/images-loaded.min.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/isotope.pkgd.min.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/counter.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/ajax-mail.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins/material-scrolltop.js');?>"></script>

    <!-- Minify Version -->
    <!-- <script src="<?=base_url('asset/js/vendor.min.js');?>"></script>
    <script src="<?=base_url('asset/js/plugins.min.js');?>"></script> -->

    <!--Main JS (Common Activation Codes)-->
    <script src="<?=base_url('asset/js/main.js');?>"></script>


      <!-- Particles js -->
      <script src="<?=content_url('assets/js/particles.js');?>"></script>
        <script src="<?=content_url('assets/js/app.js');?>"></script> 	  

</body>

</html>
